#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

ip=""


Green_font_prefix="\033[32m" && Red_font_prefix="\033[31m" && Green_background_prefix="\033[42;37m" && Red_background_prefix="\033[41;37m" && Font_color_suffix="\033[0m"
Info="${Green_font_prefix}[信息]${Font_color_suffix}"
Error="${Red_font_prefix}[错误]${Font_color_suffix}"
Tip="${Green_font_prefix}[注意]${Font_color_suffix}"

check_root(){
	[[ $EUID != 0 ]] && echo -e "${Error} 当前非ROOT账号(或没有ROOT权限)，无法继续操作，请更换ROOT账号或使用 ${Green_background_prefix}sudo su${Font_color_suffix} 命令获取临时ROOT权限（执行后可能会提示输入当前账号的密码）。" && exit 1
}

yum_install(){
	echo -e "--------yum依赖安装开始-----------"
	# 检测yum是否可用
	[ $(yum repolist | awk '/repolist/{print$2}' | sed 's/,//') -eq 0 ] && echo "${Error} yum源存在问题 !" && exit 2
	# 开始安装依赖
	for i in gcc pcre pcre-devel zlib zlib-devel openssl openssl-devel gcc-c++ supervisor screen inotify-tools epel-release nginx
	do
		rpm -qa | grep ${i%%.*} &>/dev/null
		[ $? -eq 0 ] || yum install -y $i&>/dev/null && echo -e "${Info} "$i"安装完成 !"
		[ $? -ne 0 ] && echo -e "${Error} yum安装 "$i"失败 !"&& exit 3
	done
}

install_confd(){
	if [[ -x /usr/bin/confd ]]; then
		echo -e "${Tip} 已经安装confd，跳过 !"
	else
		curl -L https://github.com/kelseyhightower/confd/releases/download/v0.16.0/confd-0.16.0-linux-amd64 -o /usr/bin/confd &>/dev/null
		chmod +x /usr/bin/confd
		echo -e "${Info} confd 安装成功 !"
	fi
}

copy_config(){
	echo -e "-------------------------------"
	mkdir -p /etc/confd/{conf.d,templates}
	cp -f conf.d/* /etc/confd/conf.d
	cp -f templates/* /etc/confd/templates
	cp -f supervisord.conf /etc/supervisord.conf

	sed -i "s/1.1.1.1/${ip}/g" /etc/supervisord.conf
	echo -e "${Info} 配置文件迁移完成 !"
}

autorun(){
	echo -e "-------------------------------"
	systemctl enable nginx.service &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} nginx自启配置失败 !" && exit 1
	else
	    echo -e "${Info} nginx自启配置成功 !"
	fi

	systemctl enable supervisord.service &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} supervisord自启配置失败 !" && exit 1
	else
	    echo -e "${Info} supervisord自启配置成功 !"
	fi

	systemctl start nginx &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} nginx 启动失败 !" && exit 1
	else
	    echo -e "${Info} nginx 启动成功 !"
	fi

	systemctl start supervisord &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} supervisord 启动失败 !" && exit 1
	else
	    echo -e "${Info} supervisord 启动成功 !"
	fi

	echo -e "--------------完成----------------"
	echo -e "${Info} 顺利完成安装 !!!"
	echo -e "${Tip} 你可以查看nginx配置是否同步成功：cat /etc/nginx/nginx.conf "
}

# 检查root权限
check_root

# 接收参数
if [[ $1 = "-i" ]]; then
	ip=$2
fi


if [[ ${#ip} -lt 7 ]]; then
	echo -e "${Error} ip填写不正确 !"
	echo -e "${Error} 使用方法 ./install.sh -i <ip地址>" && exit 1
fi


echo -e "${Info} 请检查配置：ip为 [${ip}] !"


# yum安装依赖（包括supervisor + nginx）
yum_install

# 安装confd
install_confd

# 复制config文件
copy_config

# 启动并添加开机自启 supervisor + nginx
autorun
